﻿namespace EntFrm.AutoUpdate.Models
{
    public class ServVersion
    {
        public string VerNo { get; set; }
        public string VerName { get; set; }
        public string VerCode { get; set; }
        public string VerType { get; set; }
        public string AppStart { get; set; }
        public string Platform { get; set; }
        public string UpdtMode { get; set; }
        public string FileUrl { get; set; }
        public string VerDesc { get; set; }
    }
}
