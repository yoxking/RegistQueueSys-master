﻿namespace EntFrm.AutoUpdate
{
    public class LocalVersion
    {
        public string VerCode { get; set; }
        public string VerType { get; set; }
    }
}
