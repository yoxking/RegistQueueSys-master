﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntFrm.AutoUpdate.Pubutils
{
   public class UpdateWork
    {
        public delegate void UpdateProgess(double data);
        public UpdateProgess OnUpdateProgess;

        //临时目录（WIN7以及以上在C盘只有对于temp目录有操作权限）
        private string tempsPath = Path.Combine(Environment.GetEnvironmentVariable("TEMP"), @"AutoUpdate\temps\");
        private string bakupPath = Path.Combine(Environment.GetEnvironmentVariable("TEMP"), @"AutoUpdate\bakup\");

        private string processName;
        private string programName = "EntFrm.CallerConsole.exe";
        private LocalVersion localVersion;
        private ServVersion servVersion;
        private bool updateFlag = false;


        /// <summary>
        /// 初始化配置目录信息
        /// </summary>
        public UpdateWork()
        {
            GetLocalVersion();
            GetServVersion();
            if (localVersion != null && servVersion != null)
            {
                Process process = Process.GetCurrentProcess();
                processName = Path.GetFileName(process.MainModule.FileName);

                //创建备份目录信息
                DirectoryInfo bakupinfo = new DirectoryInfo(bakupPath);
                if (bakupinfo.Exists == false)
                {
                    bakupinfo.Create();
                }
                //创建临时目录信息
                DirectoryInfo tempsinfo = new DirectoryInfo(tempsPath);
                if (tempsinfo.Exists == false)
                {
                    tempsinfo.Create();
                }

                updateFlag = true;
            }

        }

        /// <summary>
        /// 获取更新的服务器端的数据信息
        /// </summary>
        /// <returns></returns>
        private void GetLocalVersion()
        {
            localVersion = new LocalVersion();
            localVersion.VerType = IPublicHelper.Get_ConfigValue("VerType");
            localVersion.VerCode = IPublicHelper.Get_ConfigValue("VerCode");
        }

        /// <summary>
        /// 获取更新的服务器端的数据信息
        /// </summary>
        /// <returns></returns>
        private void GetServVersion()
        {
            string s = IUserContext.OnExecuteCommand_Xp("getVersionInfo", new string[] { localVersion.VerType, localVersion.VerCode });
            if (!string.IsNullOrEmpty(s))
            {
                servVersion = JsonConvert.DeserializeObject<ServVersion>(s);
            }
            else
            {
                servVersion = null;
            }
        }

        public bool DoWork()
        {
            if (updateFlag)
            {
                //1、杀死进程
                Kill();
                Thread.Sleep(400);
                //2、更新之前先备份
                Bakup();
                Thread.Sleep(400);
                //3、备份结束开始下载文件
                Download();//下载更新包文件信息
                Thread.Sleep(400);
                //3、开始更新
                Update();
                Thread.Sleep(400);
                //4、启动程序
                Startup();
                Thread.Sleep(400);

                return true;
            }
            return false;
        }

        /// <summary>
        /// 杀掉当前运行的程序进程
        /// </summary>
        /// <param name="programName">程序名称</param>
        public void Kill()
        {
            Process[] processes = Process.GetProcessesByName(programName);
            foreach (Process p in processes)
            {
                p.Kill();
                p.Close();
            }
            OnUpdateProgess?.Invoke(10);
        }

        /// <summary>
        /// 备份当前的程序目录信息
        /// </summary>
        private IUpdateWork Bakup()
        {
            try
            {
                DirectoryInfo di = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
                foreach (var item in di.GetFiles())
                {
                    if (item.Name != processName)//当前文件不需要备份
                    {
                        File.Copy(item.FullName, bakupPath + item.Name, true);
                    }
                }
                //文件夹复制
                foreach (var item in di.GetDirectories())
                {
                    if (item.Name != "bakup" && item.Name != "temps")
                    {
                        CopyDirectory(item.FullName, bakupPath);
                    }
                }
                OnUpdateProgess?.Invoke(20);
                return this;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 下载方法
        /// </summary>
        private IUpdateWork Download()
        {
            string fileName = servVersion.FileUrl.Substring(servVersion.FileUrl.LastIndexOf("/") + 1);

            HttpDwload.DownloadFileTaskAsync(servVersion.FileUrl, tempsPath + fileName, (sender, e) =>
            {
                int d = (int)((e.BytesReceived * 1.0 / e.TotalBytesToReceive * 1.0) * 100000.0);

                OnUpdateProgess?.Invoke(d);

            }, (sender, e) =>
            {
                // OnUpdateProgess?.Invoke(60 / UpdateVerList.Count);

            });

            return this;
        }

        private IUpdateWork Update()
        {
            OnUpdateProgess?.Invoke(98);
            return this;
        }

        private IUpdateWork Startup()
        {
            Process.Start(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "EntFrm.CallerConsole.exe"));
            OnUpdateProgess?.Invoke(100);
            return this;
        }

        /// <summary>
        /// 更新失败的情况下，回滚当前更新
        /// </summary>
        private IUpdateWork Restore()
        {
            DeleteLocalFiles();
            CopyDirectory(bakupPath, AppDomain.CurrentDomain.BaseDirectory);
            return this;
        }

        /// <summary>
        /// 更新配置信息
        /// </summary>
        private IUpdateWork UpdateVer()
        {

            return this;
        }

        /// <summary>
        /// 文件拷贝
        /// </summary>
        /// <param name="srcdir">源目录</param>
        /// <param name="desdir">目标目录</param>
        private IUpdateWork CopyDirectory(string srcdir, string desdir)
        {
            string folderName = srcdir.Substring(srcdir.LastIndexOf("\\") + 1);

            string desfolderdir = desdir + "\\" + folderName;

            if (desdir.LastIndexOf("\\") == (desdir.Length - 1))
            {
                desfolderdir = desdir + folderName;
            }
            string[] filenames = Directory.GetFileSystemEntries(srcdir);
            foreach (string file in filenames)// 遍历所有的文件和目录
            {
                if (Directory.Exists(file))// 先当作目录处理如果存在这个目录就递归Copy该目录下面的文件
                {
                    string currentdir = desfolderdir + "\\" + file.Substring(file.LastIndexOf("\\") + 1);
                    if (!Directory.Exists(currentdir))
                    {
                        Directory.CreateDirectory(currentdir);
                    }
                    CopyDirectory(file, desfolderdir);
                }
                else // 否则直接copy文件
                {
                    string srcfileName = file.Substring(file.LastIndexOf("\\") + 1);
                    srcfileName = desfolderdir + "\\" + srcfileName;
                    if (!Directory.Exists(desfolderdir))
                    {
                        Directory.CreateDirectory(desfolderdir);
                    }
                    File.Copy(file, srcfileName, true);
                }
            }
            return this;
        }


        /// <summary>
        /// 删除本地文件夹的文件
        /// </summary>
        private IUpdateWork DeleteLocalFiles()
        {
            DirectoryInfo di = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            foreach (var item in di.GetFiles())
            {
                if (item.Name != processName)
                {
                    if (item.Name != "EntFrm.CallerConsole.exe.config")
                    {
                        File.Delete(item.FullName);
                    }
                }
            }
            foreach (var item in di.GetDirectories())
            {
                if (item.Name != "bakup" && item.Name != "temps")
                {
                    item.Delete(true);
                }
            }
            return this;
        }


        /// <summary>
        /// 删除临时文件
        /// </summary>
        private IUpdateWork DeleteTempFile(String name)
        {
            FileInfo file = new FileInfo(tempsPath + name);
            file.Delete();
            return this;
        }


        /// <summary>
        /// 删除本地文件
        /// </summary>
        private IUpdateWork DeleteLocalFile(string name)
        {
            if (File.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, name)))
            {
                FileInfo file = new FileInfo(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, name));
                file.Delete();
            }
            return this;
        }
    }
}